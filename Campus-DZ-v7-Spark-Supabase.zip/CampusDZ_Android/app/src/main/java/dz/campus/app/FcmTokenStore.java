package dz.campus.app;

import android.content.Context;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.messaging.FirebaseMessaging;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;

public final class FcmTokenStore {
    private FcmTokenStore() {}
    public static void sync(Context context) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) return;
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(token -> save(user, token));
    }
    public static void saveCurrent(String token) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null && token != null && !token.isEmpty()) save(user, token);
    }
    private static void save(FirebaseUser user, String token) {
        user.getIdToken(false).addOnSuccessListener(result -> {
            boolean admin = Boolean.TRUE.equals(result.getClaims().get("admin"));
            Map<String,Object> data = new HashMap<>();
            data.put("token", token);
            data.put("role", admin ? "admin" : "student");
            data.put("updatedAt", FieldValue.serverTimestamp());
            FirebaseFirestore.getInstance().collection("fcmTokens").document(user.getUid())
                .collection("tokens").document(hash(token)).set(data);
        });
    }
    private static String hash(String value) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256").digest(value.getBytes("UTF-8"));
            StringBuilder out = new StringBuilder();
            for (byte b : bytes) out.append(String.format(java.util.Locale.US, "%02x", b));
            return out.toString();
        } catch (Exception e) { return Integer.toHexString(value.hashCode()); }
    }
}
