import { createRemoteJWKSet, importPKCS8, jwtVerify, SignJWT } from "https://deno.land/x/jose@v5.9.6/index.ts";

const PROJECT_ID = "campus-dz-d2a18";
const FIRESTORE = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents`;
const JWKS = createRemoteJWKSet(new URL("https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com"));
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS", "Content-Type": "application/json" };

function response(status: number, body: Record<string, unknown>) { return new Response(JSON.stringify(body), { status, headers: cors }); }
function decodeFirestoreValue(v: any): any {
  if (!v) return null;
  if ("stringValue" in v) return v.stringValue;
  if ("booleanValue" in v) return v.booleanValue;
  if ("integerValue" in v) return Number(v.integerValue);
  if ("timestampValue" in v) return v.timestampValue;
  if ("mapValue" in v) return Object.fromEntries(Object.entries(v.mapValue.fields || {}).map(([k,x]) => [k, decodeFirestoreValue(x)]));
  return null;
}
function encodeValue(v: string) { return { stringValue: v }; }

async function googleAccessToken(sa: any): Promise<string> {
  const key = await importPKCS8(sa.private_key, "RS256");
  const now = Math.floor(Date.now() / 1000);
  const assertion = await new SignJWT({ scope: "https://www.googleapis.com/auth/firebase.messaging https://www.googleapis.com/auth/datastore" })
    .setProtectedHeader({ alg: "RS256", typ: "JWT" }).setIssuer(sa.client_email)
    .setAudience("https://oauth2.googleapis.com/token").setIssuedAt(now).setExpirationTime(now + 3600).sign(key);
  const form = new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion });
  const r = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: form });
  const j = await r.json(); if (!r.ok) throw new Error(`Google OAuth failed: ${JSON.stringify(j)}`);
  return j.access_token;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return response(405, { ok: false, error: "Method not allowed" });
  try {
    const auth = req.headers.get("Authorization") || "";
    const idToken = auth.replace(/^Bearer\s+/i, "");
    if (!idToken || idToken === auth) return response(401, { ok: false, error: "Missing Firebase ID token" });
    const verified = await jwtVerify(idToken, JWKS, { issuer: `https://securetoken.google.com/${PROJECT_ID}`, audience: PROJECT_ID });
    const uid = String(verified.payload.user_id || verified.payload.sub || "");
    if (!uid) return response(401, { ok: false, error: "Invalid Firebase user" });
    const body = await req.json();
    const action = body.action;
    if (action !== "new_application" && action !== "status_change") return response(400, { ok: false, error: "Invalid action" });

    const saText = Deno.env.get("CAMPUS_FIREBASE_SERVICE_ACCOUNT");
    if (!saText) return response(500, { ok: false, error: "Server service-account secret is not configured" });
    const sa = JSON.parse(saText);
    if (sa.project_id !== PROJECT_ID) return response(500, { ok: false, error: "Service account project mismatch" });
    const access = await googleAccessToken(sa);
    const fsHeaders = { Authorization: `Bearer ${access}`, "Content-Type": "application/json" };

    let targets: string[] = [];
    let title = ""; let message = ""; let data: Record<string,string> = {};
    if (action === "new_application") {
      if (body.uid !== uid) return response(403, { ok: false, error: "UID mismatch" });
      const appRes = await fetch(`${FIRESTORE}/studentApplications/${encodeURIComponent(uid)}`, { headers: fsHeaders });
      if (!appRes.ok) return response(403, { ok: false, error: "Application not found" });
      const appDoc = await appRes.json();
      const fields = Object.fromEntries(Object.entries(appDoc.fields || {}).map(([k,v]) => [k, decodeFirestoreValue(v)]));
      if (fields.status !== "pending") return response(403, { ok: false, error: "Application is not pending" });
      const q = await fetch(`${FIRESTORE}:runQuery`, { method: "POST", headers: fsHeaders, body: JSON.stringify({ structuredQuery: { from: [{ collectionId: "tokens", allDescendants: true }], where: { fieldFilter: { field: { fieldPath: "role" }, op: "EQUAL", value: encodeValue("admin") } } } }) });
      if (!q.ok) throw new Error(`Firestore admin token query failed: ${await q.text()}`);
      const rows = await q.json();
      targets = (rows || []).map((r:any) => decodeFirestoreValue(r.document?.fields?.token)).filter((x:any) => typeof x === "string" && x.length > 20);
      title = "طلب تسجيل جديد";
      message = `وصل طلب تسجيل جديد للطالب ${String(fields.studentNumber || "")} ويحتاج إلى المراجعة.`;
      data = { type: "new_application", uid, studentNumber: String(fields.studentNumber || "") };
    } else {
      if (verified.payload.admin !== true) return response(403, { ok: false, error: "Admin permission required" });
      const targetUid = String(body.uid || "");
      const status = String(body.status || "");
      if (!targetUid || !["approved", "rejected", "suspended"].includes(status)) return response(400, { ok: false, error: "Invalid target or status" });
      const appRes = await fetch(`${FIRESTORE}/studentApplications/${encodeURIComponent(targetUid)}`, { headers: fsHeaders });
      if (!appRes.ok) return response(404, { ok: false, error: "Student application not found" });
      const appDoc = await appRes.json();
      const fields = Object.fromEntries(Object.entries(appDoc.fields || {}).map(([k,v]) => [k, decodeFirestoreValue(v)]));
      if (fields.status !== status) return response(409, { ok: false, error: "Application status does not match" });
      const tokenRes = await fetch(`${FIRESTORE}/fcmTokens/${encodeURIComponent(targetUid)}/tokens`, { headers: fsHeaders });
      if (tokenRes.ok) { const tokenDoc = await tokenRes.json(); targets = (tokenDoc.documents || []).map((d:any) => decodeFirestoreValue(d.fields?.token)).filter((x:any) => typeof x === "string" && x.length > 20); }
      const reason = String(fields.rejectionReason || "").trim();
      title = "تحديث حسابك في Campus DZ";
      message = status === "approved" ? "تهانينا! تمت الموافقة على حسابك. يمكنك الآن الدخول إلى Campus DZ." : status === "rejected" ? (reason ? `تم رفض طلبك. السبب: ${reason}` : "تم رفض طلب تسجيلك. يرجى التواصل مع الإدارة.") : "تم إيقاف حسابك من طرف الإدارة.";
      data = { type: "status_update", status, reason };
    }

    let sent = 0; let failed = 0;
    for (const token of targets) {
      const r = await fetch(`https://fcm.googleapis.com/v1/projects/${PROJECT_ID}/messages:send`, { method: "POST", headers: { Authorization: `Bearer ${access}`, "Content-Type": "application/json" }, body: JSON.stringify({ message: { token, notification: { title, body: message }, data, android: { priority: "HIGH", notification: { channel_id: "campus_updates", sound: "default" } } } }) });
      if (r.ok) sent++; else failed++;
    }
    return response(200, { ok: true, sent, failed, targets: targets.length });
  } catch (e) {
    console.error(e);
    return response(500, { ok: false, error: e instanceof Error ? e.message : "Unexpected server error" });
  }
});
