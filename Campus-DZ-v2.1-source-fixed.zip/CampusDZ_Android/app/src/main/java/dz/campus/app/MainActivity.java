package dz.campus.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.util.Base64;
import android.graphics.Color;
import android.view.Window;

import com.google.android.gms.tasks.Tasks;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageMetadata;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 4102;
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private FirebaseStorage storage;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(16,43,70));
        getWindow().setNavigationBarColor(Color.BLACK);
        FirebaseApp.initializeApp(this);
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(243,246,250));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadsImagesAutomatically(true);
        webView.addJavascriptInterface(new CampusBridge(), "CampusBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                try { startActivityForResult(Intent.createChooser(intent, "اختر صورة البطاقة"), FILE_CHOOSER_REQUEST); }
                catch (Exception e) { filePathCallback = null; return false; }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void js(String method, JSONObject data) {
        runOnUiThread(() -> webView.evaluateJavascript("window.onCampusResult && window.onCampusResult(" + JSONObject.quote(method) + "," + data.toString() + ")", null));
    }
    private JSONObject result(boolean ok, String message) {
        JSONObject o = new JSONObject(); try { o.put("ok", ok); o.put("message", message); } catch(Exception ignored){} return o;
    }
    private String emailFor(String sid) { return sid + "@campusdz.app"; }
    private boolean validSid(String sid) { return sid != null && sid.matches("[0-9]{8}"); }
    private byte[] decodeImage(String data) {
        if (data == null || data.length() < 20) return null;
        int comma = data.indexOf(',');
        String raw = comma >= 0 ? data.substring(comma + 1) : data;
        try { return Base64.decode(raw, Base64.DEFAULT); } catch(Exception e) { return null; }
    }

    private class CampusBridge {
        @JavascriptInterface public void register(String sid, String password, String front, String back) {
            if (!validSid(sid)) { js("register", result(false, "يجب أن يتكون الرقم الجامعي من 8 أرقام.")); return; }
            if (password == null || password.length() < 6) { js("register", result(false, "كلمة المرور يجب أن تكون 6 أحرف على الأقل.")); return; }
            byte[] frontBytes = decodeImage(front), backBytes = decodeImage(back);
            if (frontBytes == null) { js("register", result(false, "صورة الوجه الأمامي مطلوبة.")); return; }
            if (frontBytes.length > 5*1024*1024 || (backBytes != null && backBytes.length > 5*1024*1024)) { js("register", result(false, "حجم كل صورة يجب ألا يتجاوز 5 ميغابايت.")); return; }
            auth.createUserWithEmailAndPassword(emailFor(sid), password).addOnSuccessListener(authResult -> {
                FirebaseUser user = authResult.getUser(); if (user == null) { js("register", result(false, "تعذر إنشاء الحساب.")); return; }
                String uid = user.getUid();
                StorageReference frontRef = storage.getReference().child("studentCards/"+uid+"/front.jpg");
                StorageReference backRef = storage.getReference().child("studentCards/"+uid+"/back.jpg");
                StorageMetadata imageMeta = new StorageMetadata.Builder().setContentType("image/jpeg").build();
                com.google.android.gms.tasks.Task<Void> frontTask = frontRef.putBytes(frontBytes, imageMeta).continueWithTask(t -> { if (!t.isSuccessful()) throw t.getException(); return Tasks.forResult(null); });
                com.google.android.gms.tasks.Task<Void> backTask = backBytes == null ? Tasks.forResult(null) : backRef.putBytes(backBytes, imageMeta).continueWithTask(t -> { if (!t.isSuccessful()) throw t.getException(); return Tasks.forResult(null); });
                Tasks.whenAll(frontTask, backTask).addOnSuccessListener(v -> {
                    Map<String,Object> app = new HashMap<>(); app.put("uid",uid); app.put("studentNumber",sid); app.put("status","pending"); app.put("frontPath","studentCards/"+uid+"/front.jpg"); app.put("backPath",backBytes == null ? "" : "studentCards/"+uid+"/back.jpg"); app.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                    Map<String,Object> number = new HashMap<>(); number.put("uid",uid); number.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                    db.runTransaction(transaction -> {
                        transaction.set(db.collection("studentNumbers").document(sid), number);
                        transaction.set(db.collection("studentApplications").document(uid), app);
                        return null;
                    }).addOnSuccessListener(x -> js("register", result(true,"تم إرسال طلبك بنجاح. حسابك الآن قيد المراجعة.")))
                      .addOnFailureListener(e -> { frontRef.delete(); if(backBytes!=null) backRef.delete(); user.delete(); js("register", result(false, (e.getMessage()!=null && e.getMessage().contains("PERMISSION_DENIED")) ? "هذا الرقم الجامعي مسجل مسبقًا أو تعذر إتمام الطلب." : friendly(e))); });
                }).addOnFailureListener(e -> { frontRef.delete(); backRef.delete(); user.delete(); js("register", result(false,"تعذر رفع صور البطاقة: "+friendly(e))); });
            }).addOnFailureListener(e -> js("register", result(false, friendly(e))));
        }

        @JavascriptInterface public void login(String sid, String password) {
            if (!validSid(sid) || password == null || password.isEmpty()) { js("login", result(false,"أدخل رقمًا جامعيًا صحيحًا وكلمة المرور.")); return; }
            auth.signInWithEmailAndPassword(emailFor(sid), password).addOnSuccessListener(a -> {
                FirebaseUser user = auth.getCurrentUser();
                if (user == null) { js("login", result(false,"تعذر التحقق من الحساب.")); return; }
                user.getIdToken(true).addOnSuccessListener(token -> {
                    Object admin = token.getClaims().get("admin");
                    if (Boolean.TRUE.equals(admin)) { JSONObject o=result(true,"تم الدخول بصلاحية المدير."); try{o.put("role","admin");o.put("uid",user.getUid());}catch(Exception ignored){} js("login",o); return; }
                    db.collection("studentApplications").document(user.getUid()).get().addOnSuccessListener(doc -> {
                        String status = doc.getString("status");
                        if ("approved".equals(status)) { JSONObject o=result(true,"مرحبًا بك في Campus DZ."); try{o.put("role","student");o.put("uid",user.getUid());o.put("studentNumber",sid);}catch(Exception ignored){} js("login",o); }
                        else { auth.signOut(); String msg="pending".equals(status)?"حسابك قيد المراجعة. ستتمكن من الدخول بعد موافقة المدير.":"rejected".equals(status)?"تم رفض طلب التسجيل. يرجى التواصل مع الإدارة.":"suspended".equals(status)?"تم إيقاف حسابك.":"لم يتم العثور على طلب تحقق لهذا الحساب."; js("login",result(false,msg)); }
                    }).addOnFailureListener(e -> { auth.signOut(); js("login",result(false,"تعذر التحقق من حالة الحساب.")); });
                }).addOnFailureListener(e -> js("login",result(false,friendly(e))));
            }).addOnFailureListener(e -> js("login",result(false,"رقم التسجيل أو كلمة المرور غير صحيحة.")));
        }

        @JavascriptInterface public void logout() { auth.signOut(); }

        @JavascriptInterface public void adminList() {
            FirebaseUser u=auth.getCurrentUser(); if(u==null){js("adminList",result(false,"سجّل الدخول أولًا."));return;}
            u.getIdToken(true).addOnSuccessListener(token->{ if(!Boolean.TRUE.equals(token.getClaims().get("admin"))){js("adminList",result(false,"ليست لديك صلاحية المدير."));return;}
                db.collection("studentApplications").get().addOnSuccessListener(snap->{ JSONArray arr=new JSONArray(); for(DocumentSnapshot d:snap.getDocuments()){ JSONObject x=new JSONObject(); try{x.put("uid",d.getId());x.put("studentNumber",d.getString("studentNumber"));x.put("status",d.getString("status"));x.put("frontPath",d.getString("frontPath"));x.put("backPath",d.getString("backPath"));arr.put(x);}catch(Exception ignored){} } JSONObject o=result(true,"تم تحميل الطلبات.");try{o.put("items",arr);}catch(Exception ignored){}js("adminList",o); }).addOnFailureListener(e->js("adminList",result(false,friendly(e))));
            }).addOnFailureListener(e->js("adminList",result(false,friendly(e))));
        }
        @JavascriptInterface public void adminSetStatus(String uid, String status) {
            if (!"approved".equals(status) && !"rejected".equals(status) && !"suspended".equals(status)) { js("adminAction",result(false,"حالة غير صالحة.")); return; }
            FirebaseUser u=auth.getCurrentUser(); if(u==null){js("adminAction",result(false,"سجّل الدخول أولًا."));return;}
            u.getIdToken(true).addOnSuccessListener(token->{ if(!Boolean.TRUE.equals(token.getClaims().get("admin"))){js("adminAction",result(false,"ليست لديك صلاحية المدير."));return;}
                Map<String,Object> update=new HashMap<>();update.put("status",status);update.put("reviewedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());update.put("reviewedBy",u.getUid());
                db.collection("studentApplications").document(uid).update(update).addOnSuccessListener(v->js("adminAction",result(true,"تم تحديث حالة الحساب."))).addOnFailureListener(e->js("adminAction",result(false,friendly(e))));
            }).addOnFailureListener(e->js("adminAction",result(false,friendly(e))));
        }
        @JavascriptInterface public void adminDeleteCard(String uid) {
            FirebaseUser u=auth.getCurrentUser(); if(u==null)return;
            u.getIdToken(true).addOnSuccessListener(token->{if(!Boolean.TRUE.equals(token.getClaims().get("admin"))){js("adminDelete",result(false,"ليست لديك صلاحية المدير."));return;}
                StorageReference folder=storage.getReference().child("studentCards/"+uid);
                Tasks.whenAllComplete(folder.child("front.jpg").delete(),folder.child("back.jpg").delete()).addOnCompleteListener(task->{
                    Map<String,Object> update=new HashMap<>();update.put("frontPath","");update.put("backPath","");update.put("cardDeletedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                    db.collection("studentApplications").document(uid).update(update).addOnSuccessListener(v->js("adminDelete",result(true,"تم حذف صور البطاقة."))).addOnFailureListener(e->js("adminDelete",result(false,friendly(e))));
                });
            });
        }
        @JavascriptInterface public void adminImageUrl(String path, String callbackKey) {
            FirebaseUser u=auth.getCurrentUser(); if(u==null)return;
            u.getIdToken(true).addOnSuccessListener(token->{if(!Boolean.TRUE.equals(token.getClaims().get("admin")))return;
                storage.getReference().child(path).getBytes(5L*1024L*1024L).addOnSuccessListener(bytes->{JSONObject o=result(true,"ok");try{o.put("image",Base64.encodeToString(bytes,Base64.NO_WRAP));o.put("key",callbackKey);}catch(Exception ignored){}js("adminImage",o);}).addOnFailureListener(e->js("adminImage",result(false,friendly(e))));
            });
        }
    }
    private String friendly(Exception e) { String m=e==null?"حدث خطأ غير متوقع.":e.getMessage(); return m==null?"حدث خطأ غير متوقع.":m; }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==FILE_CHOOSER_REQUEST&&filePathCallback!=null){Uri[] results=null;if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)results=new Uri[]{data.getData()};filePathCallback.onReceiveValue(results);filePathCallback=null;}}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
