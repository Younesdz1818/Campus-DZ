مشروع Campus DZ لنظام Android — نسخة مجهزة

مهم:
- هذا الملف يحتوي على مصدر المشروع وليس APK جاهزاً.
- التطبيق يعرض ملف index.html الموجود داخل assets باستعمال WebView.
- المشروع لا يحتوي على مكتبات native بصيغة .so، لذلك لا يحتاج اختيار ARM32 أو ARM64؛
  ملف APK الناتج سيكون مناسباً لمعظم معماريات أندرويد المدعومة.
- الحد الأدنى للنظام Android 6.0 (API 23).

إنشاء APK باستعمال Android Studio على الكمبيوتر:
1) ثبّت Android Studio بإصدار مستقر. استخدم JDK 17 (المرفق مع Android Studio مناسب).
2) فك ضغط الملف.
3) افتح Android Studio ثم File > Open واختر مجلد CampusDZ_Android.
4) انتظر Gradle Sync، واسمح بتثبيت Android SDK Platform 35 وBuild Tools إذا طُلب ذلك.
5) اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
6) بعد نجاح البناء اضغط Locate. غالباً ستجد الملف في:
   app/build/outputs/apk/debug/app-debug.apk

لإنشاء نسخة Release موقّعة:
1) اختر Build > Generate Signed Bundle / APK.
2) اختر APK.
3) أنشئ keystore أو اختر keystore سابقاً، ثم اختر release.
4) احتفظ بملف keystore وكلمات المرور؛ ستحتاجها لتحديث التطبيق لاحقاً.

الإعدادات:
- Android Gradle Plugin: 8.7.3
- Gradle الموصى به: 8.9
- JDK: 17
- compileSdk: 35
- minSdk: 23
- التطبيق Java/WebView ولا يحتوي على مكتبات native أو قيود ABI.

تنبيه: هذا المشروع واجهة تجريبية ولا يحتوي على قاعدة بيانات أو تسجيل دخول حقيقي
أو مصادقة إدارية آمنة. لا تدخل كلمات مرور أو بيانات طلاب حقيقية.
