package dz.campus.app;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.util.Base64;
import android.graphics.Color;
import android.view.Window;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.Executor;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 4102;
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private static final String SUPABASE_FUNCTION_URL = "https://fucfpxtwlptoxnfxhavm.supabase.co/functions/v1/card-storage";
    private static final String SUPABASE_PUSH_URL = "https://fucfpxtwlptoxnfxhavm.supabase.co/functions/v1/send-notification";
    private static final String SUPABASE_PUBLISHABLE_KEY = "sb_publishable_ICVgVaO2-vO7_SV9kldm1g_BVSLPQDT";
    private final Executor networkExecutor = java.util.concurrent.Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(16,43,70));
        getWindow().setNavigationBarColor(Color.BLACK);
        FirebaseApp.initializeApp(this);
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7301);
        }
        FcmTokenStore.sync(this);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(243,246,250));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadsImagesAutomatically(true);
        webView.addJavascriptInterface(new CampusBridge(), "CampusBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                try { startActivityForResult(Intent.createChooser(intent, "اختر صورة البطاقة"), FILE_CHOOSER_REQUEST); }
                catch (Exception e) { filePathCallback = null; return false; }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void js(String method, JSONObject data) {
        runOnUiThread(() -> webView.evaluateJavascript("window.onCampusResult && window.onCampusResult(" + JSONObject.quote(method) + "," + data.toString() + ")", null));
    }
    private JSONObject result(boolean ok, String message) {
        JSONObject o = new JSONObject(); try { o.put("ok", ok); o.put("message", message); } catch(Exception ignored){} return o;
    }
    private String emailFor(String sid) { return sid + "@campusdz.app"; }
    private boolean validSid(String sid) { return sid != null && sid.matches("[0-9]{8}"); }
    private byte[] decodeImage(String data) {
        if (data == null || data.length() < 20) return null;
        int comma = data.indexOf(',');
        String raw = comma >= 0 ? data.substring(comma + 1) : data;
        try { return Base64.decode(raw, Base64.DEFAULT); } catch(Exception e) { return null; }
    }

    private String extensionFor(String data) { return data != null && data.startsWith("data:image/png") ? "png" : "jpg"; }
    private String contentTypeFor(String data) { return "png".equals(extensionFor(data)) ? "image/png" : "image/jpeg"; }
    private JSONObject callCardStorage(String idToken, JSONObject payload) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(SUPABASE_FUNCTION_URL).openConnection();
        conn.setRequestMethod("POST"); conn.setConnectTimeout(20000); conn.setReadTimeout(30000);
        conn.setDoOutput(true); conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("apikey", SUPABASE_PUBLISHABLE_KEY);
        conn.setRequestProperty("Authorization", "Bearer " + idToken);
        byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream out = conn.getOutputStream()) { out.write(body); }
        int code = conn.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        if (in != null) { byte[] chunk = new byte[8192]; int n; while ((n = in.read(chunk)) != -1) buffer.write(chunk, 0, n); in.close(); }
        conn.disconnect();
        JSONObject response = new JSONObject(buffer.toString("UTF-8"));
        if (code < 200 || code >= 300 || !response.optBoolean("ok", false))
            throw new Exception(response.optString("error", "Supabase request failed (" + code + ")"));
        return response;
    }
    private void sendPushEvent(String idToken, JSONObject payload) {
        networkExecutor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(SUPABASE_PUSH_URL).openConnection();
                conn.setRequestMethod("POST"); conn.setConnectTimeout(15000); conn.setReadTimeout(20000); conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("apikey", SUPABASE_PUBLISHABLE_KEY);
                conn.setRequestProperty("Authorization", "Bearer " + idToken);
                try (OutputStream out = conn.getOutputStream()) { out.write(payload.toString().getBytes(StandardCharsets.UTF_8)); }
                int code = conn.getResponseCode();
                InputStream in = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
                if (in != null) { byte[] buf = new byte[2048]; while (in.read(buf) != -1) {} in.close(); }
            } catch (Exception e) { android.util.Log.w("CampusDZPush", "Push event failed", e); }
            finally { if (conn != null) conn.disconnect(); }
        });
    }
    private void notifyNewApplication(FirebaseUser user) {
        if (user == null) return;
        user.getIdToken(false).addOnSuccessListener(token -> {
            try { JSONObject body = new JSONObject(); body.put("action", "new_application"); body.put("uid", user.getUid()); sendPushEvent(token.getToken(), body); }
            catch (Exception ignored) {}
        });
    }
    private void notifyStatusChange(FirebaseUser admin, String uid, String status) {
        if (admin == null) return;
        admin.getIdToken(false).addOnSuccessListener(token -> {
            try { JSONObject body = new JSONObject(); body.put("action", "status_change"); body.put("uid", uid); body.put("status", status); sendPushEvent(token.getToken(), body); }
            catch (Exception ignored) {}
        });
    }

    private void notifyLostReturnRequest(FirebaseUser user, String reportId) {
        if (user == null || reportId == null) return;
        user.getIdToken(false).addOnSuccessListener(token -> {
            try { JSONObject body = new JSONObject(); body.put("action", "return_request"); body.put("reportId", reportId); sendPushEvent(token.getToken(), body); }
            catch (Exception ignored) {}
        });
    }

    private JSONObject storageRequest(String token, String action, String key, String value) throws Exception {
        JSONObject body = new JSONObject(); body.put("action", action); body.put(key, value);
        return callCardStorage(token, body);
    }
    private String uploadCard(String token, String side, String data) throws Exception {
        if (data == null || data.isEmpty()) return "";
        String raw = data.substring(data.indexOf(',') >= 0 ? data.indexOf(',') + 1 : 0);
        JSONObject body = new JSONObject(); body.put("action", "upload"); body.put("side", side);
        body.put("contentType", contentTypeFor(data)); body.put("imageBase64", raw);
        return callCardStorage(token, body).getString("path");
    }

    private JSONObject fetchWordPressPosts(String baseUrl, String sourceName, String sourceType) throws Exception {
        String endpoint = baseUrl + "/wp-json/wp/v2/posts?per_page=12&orderby=date&order=desc&_fields=date,link,title,excerpt";
        HttpURLConnection conn = (HttpURLConnection) new URL(endpoint).openConnection();
        conn.setRequestMethod("GET"); conn.setConnectTimeout(9000); conn.setReadTimeout(12000);
        conn.setRequestProperty("User-Agent", "CampusDZ/1.0 (university news reader)");
        conn.setRequestProperty("Accept", "application/json");
        int code = conn.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        if (in != null) { byte[] chunk = new byte[8192]; int n; while ((n = in.read(chunk)) != -1) buffer.write(chunk, 0, n); in.close(); }
        conn.disconnect();
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
        JSONArray posts = new JSONArray(buffer.toString("UTF-8"));
        JSONArray items = new JSONArray();
        for (int i = 0; i < posts.length(); i++) {
            JSONObject post = posts.optJSONObject(i); if (post == null) continue;
            JSONObject titleObj = post.optJSONObject("title"), excerptObj = post.optJSONObject("excerpt");
            JSONObject item = new JSONObject();
            item.put("title", stripHtml(titleObj == null ? "إعلان جامعي" : titleObj.optString("rendered", "إعلان جامعي")));
            item.put("excerpt", stripHtml(excerptObj == null ? "" : excerptObj.optString("rendered", "")));
            item.put("date", post.optString("date", "")); item.put("url", post.optString("link", ""));
            item.put("source", sourceName); item.put("type", sourceType);
            items.put(item);
        }
        JSONObject result = new JSONObject(); result.put("items", items); result.put("source", sourceName); return result;
    }
    private String stripHtml(String value) {
        if (value == null) return "";
        return value.replaceAll("(?is)<script[^>]*>.*?</script>", " ")
            .replaceAll("(?is)<style[^>]*>.*?</style>", " ")
            .replaceAll("<[^>]+>", " ").replace("&nbsp;", " ").replace("&#8217;", "’")
            .replace("&#8216;", "‘").replace("&amp;", "&").replace("&quot;", "\"")
            .replace("&#038;", "&").replaceAll("\\s+", " ").trim();
    }

    private class CampusBridge {
        @JavascriptInterface public void openNews(String link) {
            try {
                Uri uri = Uri.parse(link);
                String scheme = uri.getScheme(), host = uri.getHost();
                if (("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) && host != null && (host.equalsIgnoreCase("univ-tipaza.dz") || host.toLowerCase().endsWith(".univ-tipaza.dz"))) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                }
            } catch (Exception e) { android.util.Log.w("CampusDZNews", "Could not open news link", e); }
        }

        @JavascriptInterface public void loadFacultyNews(String facultyId) {
            networkExecutor.execute(() -> {
                String[][] sources = new String[][] {
                    {"science", "https://sciences.univ-tipaza.dz", "كلية العلوم"},
                    {"snv", "https://snv.univ-tipaza.dz", "كلية علوم الطبيعة والحياة"},
                    {"lla", "https://lla.univ-tipaza.dz", "كلية اللغة والأدب العربي"},
                    {"droit", "https://droit.univ-tipaza.dz", "كلية الحقوق والعلوم السياسية"},
                    {"shs", "https://shs.univ-tipaza.dz", "كلية العلوم الاجتماعية والإنسانية"},
                    {"segc", "https://segc.univ-tipaza.dz", "كلية العلوم الاقتصادية والتجارية وعلوم التسيير"}
                };
                JSONObject response;
                try {
                    String[] selected = null;
                    for (String[] source : sources) if (source[0].equals(facultyId)) { selected = source; break; }
                    if (selected == null) throw new Exception("الكلية غير معروفة.");
                    response = fetchWordPressPosts(selected[1], selected[2], "faculty");
                    response.put("ok", true);
                    response.put("message", "تم تحميل أخبار " + selected[2] + " من موقعها الرسمي.");
                    response.put("updatedAt", System.currentTimeMillis());
                } catch (Exception e) {
                    response = result(false, "تعذر تحميل أخبار الكلية حالياً. تحقق من الإنترنت وحاول مجدداً.");
                    try { response.put("items", new JSONArray()); } catch (Exception ignored) {}
                    android.util.Log.w("CampusDZNews", "Faculty news unavailable: " + facultyId, e);
                }
                js("news", response);
            });
        }

        @JavascriptInterface public void loadNews() {
            networkExecutor.execute(() -> {
                JSONArray all = new JSONArray(); JSONArray sourceStatus = new JSONArray();
                String[][] sources = new String[][] {
                    {"https://ar.univ-tipaza.dz", "جامعة تيبازة المركزية", "central"},
                    {"https://shs.univ-tipaza.dz", "كلية العلوم الاجتماعية والإنسانية", "faculty"},
                    {"https://snv.univ-tipaza.dz", "كلية علوم الطبيعة والحياة", "faculty"},
                    {"https://droit.univ-tipaza.dz", "كلية الحقوق والعلوم السياسية", "faculty"},
                    {"https://sciences.univ-tipaza.dz", "كلية العلوم", "faculty"},
                    {"https://segc.univ-tipaza.dz", "كلية العلوم الاقتصادية والتجارية وعلوم التسيير", "faculty"},
                    {"https://lla.univ-tipaza.dz", "كلية اللغة والأدب العربي", "faculty"}
                };
                int succeeded = 0;
                for (String[] source : sources) {
                    try {
                        JSONObject response = fetchWordPressPosts(source[0], source[1], source[2]);
                        JSONArray items = response.optJSONArray("items");
                        if (items != null) for (int i = 0; i < items.length(); i++) all.put(items.getJSONObject(i));
                        sourceStatus.put(source[1]); succeeded++;
                    } catch (Exception e) { android.util.Log.w("CampusDZNews", "News source unavailable: " + source[0], e); }
                }
                JSONObject response = result(succeeded > 0, succeeded > 0 ? "تم تحديث الأخبار من " + succeeded + " مصدر رسمي." : "تعذر الاتصال بالمصادر الرسمية. تحقق من الإنترنت وحاول مجدداً.");
                try { response.put("items", all); response.put("sources", sourceStatus); response.put("updatedAt", System.currentTimeMillis()); }
                catch (Exception ignored) {}
                js("news", response);
            });
        }

        @JavascriptInterface public void register(String sid, String password, String firstName, String lastName, String contactEmail, String major, String front, String back) {
            if (!validSid(sid)) { js("register", result(false, "يجب أن يتكون الرقم الجامعي من 8 أرقام.")); return; }
            if (password == null || password.length() < 6) { js("register", result(false, "كلمة المرور يجب أن تكون 6 أحرف على الأقل.")); return; }
            if (firstName == null || firstName.trim().isEmpty() || lastName == null || lastName.trim().isEmpty()
                || major == null || major.trim().isEmpty() || contactEmail == null || !android.util.Patterns.EMAIL_ADDRESS.matcher(contactEmail).matches()) {
                js("register", result(false, "يرجى إدخال الاسم واللقب والتخصص وبريد إلكتروني صحيح.")); return;
            }
            byte[] frontBytes = decodeImage(front), backBytes = decodeImage(back);
            if (frontBytes == null) { js("register", result(false, "صورة الوجه الأمامي مطلوبة.")); return; }
            if (frontBytes.length > 3*1024*1024 || (backBytes != null && backBytes.length > 3*1024*1024)) { js("register", result(false, "حجم كل صورة يجب ألا يتجاوز 3 ميغابايت.")); return; }
            auth.createUserWithEmailAndPassword(emailFor(sid), password).addOnSuccessListener(authResult -> {
                FirebaseUser user = authResult.getUser(); if (user == null) { js("register", result(false, "تعذر إنشاء الحساب.")); return; }
                String uid = user.getUid();
                user.getIdToken(true).addOnSuccessListener(token -> networkExecutor.execute(() -> {
                    try {
                        String frontPath = uploadCard(token.getToken(), "front", front);
                        String backPath = back == null || back.isEmpty() ? "" : uploadCard(token.getToken(), "back", back);
                        Map<String,Object> app = new HashMap<>(); app.put("uid",uid); app.put("studentNumber",sid); app.put("status","pending"); app.put("frontPath",frontPath); app.put("backPath",backPath); app.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                        Map<String,Object> number = new HashMap<>(); number.put("uid",uid); number.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                        Map<String,Object> student = new HashMap<>(); student.put("uid",uid); student.put("studentNumber",sid);
                        student.put("firstName",firstName.trim()); student.put("lastName",lastName.trim());
                        student.put("email",contactEmail.trim()); student.put("major",major.trim()); student.put("status","pending");
                        student.put("frontCardImage",frontPath); student.put("backCardImage",backPath);
                        student.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                        db.runTransaction(transaction -> { transaction.set(db.collection("studentNumbers").document(sid), number); transaction.set(db.collection("studentApplications").document(uid), app); transaction.set(db.collection("students").document(sid), student); return null; })
                            .addOnSuccessListener(x -> { FcmTokenStore.sync(MainActivity.this); notifyNewApplication(user); js("register", result(true,"تم إرسال طلبك بنجاح. حسابك الآن قيد المراجعة.")); })
                            .addOnFailureListener(e -> { user.delete(); js("register", result(false, (e.getMessage()!=null && e.getMessage().contains("PERMISSION_DENIED")) ? "هذا الرقم الجامعي مسجل مسبقًا أو تعذر إتمام الطلب." : friendly(e))); });
                    } catch (Exception e) { user.delete(); js("register", result(false,"تعذر رفع صور البطاقة: "+(e.getMessage()==null?"تحقق من الاتصال وإعدادات Supabase.":e.getMessage()))); }
                })).addOnFailureListener(e -> { user.delete(); js("register", result(false,"تعذر التحقق من الحساب: "+friendly(e))); });
            }).addOnFailureListener(e -> js("register", result(false, friendly(e))));
        }

        @JavascriptInterface public void restoreSession() {
            FirebaseUser user = auth.getCurrentUser();
            JSONObject out = result(true, "");
            if (user == null) {
                try { out.put("loggedIn", false); } catch (Exception ignored) {}
                js("session", out);
                return;
            }
            user.getIdToken(true).addOnSuccessListener(token -> {
                if (Boolean.TRUE.equals(token.getClaims().get("admin"))) {
                    FcmTokenStore.sync(MainActivity.this);
                    JSONObject data = result(true, "");
                    try { data.put("loggedIn", true); data.put("role", "admin"); data.put("uid", user.getUid()); } catch (Exception ignored) {}
                    js("session", data);
                    return;
                }
                db.collection("studentApplications").document(user.getUid()).get().addOnSuccessListener(app -> {
                    String status = app.getString("status");
                    if (app.exists() && "approved".equals(status)) {
                        String sid = app.getString("studentNumber");
                        FcmTokenStore.sync(MainActivity.this);
                        JSONObject data = result(true, "");
                        try { data.put("loggedIn", true); data.put("role", "student"); data.put("uid", user.getUid()); data.put("studentNumber", sid == null ? "" : sid); } catch (Exception ignored) {}
                        js("session", data);
                    } else {
                        auth.signOut();
                        String message = "pending".equals(status) ? "حسابك قيد المراجعة." : "الحساب غير متاح. يرجى تسجيل الدخول من جديد أو التواصل مع الإدارة.";
                        JSONObject data = result(false, message);
                        try { data.put("loggedIn", false); } catch (Exception ignored) {}
                        js("session", data);
                    }
                }).addOnFailureListener(e -> {
                    JSONObject data = result(false, "تعذر التحقق من جلسة الحساب. تحقق من الإنترنت ثم أعد المحاولة.");
                    try { data.put("loggedIn", false); } catch (Exception ignored) {}
                    js("session", data);
                });
            }).addOnFailureListener(e -> {
                JSONObject data = result(false, "تعذر استعادة الجلسة. تحقق من الاتصال بالإنترنت.");
                try { data.put("loggedIn", false); } catch (Exception ignored) {}
                js("session", data);
            });
        }

        @JavascriptInterface public void login(String sid, String password) {
            if (!validSid(sid) || password == null || password.isEmpty()) { js("login", result(false,"أدخل رقمًا جامعيًا صحيحًا وكلمة المرور.")); return; }
            auth.signInWithEmailAndPassword(emailFor(sid), password).addOnSuccessListener(a -> {
                FirebaseUser user = auth.getCurrentUser();
                if (user == null) { js("login", result(false,"تعذر التحقق من الحساب.")); return; }
                user.getIdToken(true).addOnSuccessListener(token -> {
                    Object admin = token.getClaims().get("admin");
                    if (Boolean.TRUE.equals(admin)) { FcmTokenStore.sync(MainActivity.this); JSONObject o=result(true,"تم الدخول بصلاحية المدير."); try{o.put("role","admin");o.put("uid",user.getUid());}catch(Exception ignored){} js("login",o); return; }
                    db.collection("studentApplications").document(user.getUid()).get().addOnSuccessListener(doc -> {
                        String status = doc.getString("status");
                        if ("approved".equals(status)) { FcmTokenStore.sync(MainActivity.this); JSONObject o=result(true,"مرحبًا بك في Campus DZ."); try{o.put("role","student");o.put("uid",user.getUid());o.put("studentNumber",sid);}catch(Exception ignored){} js("login",o); }
                        else { auth.signOut(); String msg="pending".equals(status)?"حسابك قيد المراجعة. ستتمكن من الدخول بعد موافقة المدير.":"rejected".equals(status)?"تم رفض طلب التسجيل. يرجى التواصل مع الإدارة.":"suspended".equals(status)?"تم إيقاف حسابك.":"لم يتم العثور على طلب تحقق لهذا الحساب."; js("login",result(false,msg)); }
                    }).addOnFailureListener(e -> { auth.signOut(); js("login",result(false,"تعذر التحقق من حالة الحساب.")); });
                }).addOnFailureListener(e -> js("login",result(false,friendly(e))));
            }).addOnFailureListener(e -> js("login",result(false,"رقم التسجيل أو كلمة المرور غير صحيحة.")));
        }

        @JavascriptInterface public void getStudentProfile() {
            FirebaseUser user = auth.getCurrentUser();
            if (user == null) { js("profileData", result(false, "سجّل الدخول أولاً.")); return; }
            db.collection("students").whereEqualTo("uid", user.getUid()).limit(1).get().addOnSuccessListener(snap -> {
                if (snap.isEmpty()) { js("profileData", result(false, "لم يتم العثور على ملف الطالب.")); return; }
                DocumentSnapshot doc = snap.getDocuments().get(0);
                JSONObject data = result(true, "تم تحميل بيانات الطالب.");
                try { data.put("firstName", doc.getString("firstName")); data.put("lastName", doc.getString("lastName")); data.put("major", doc.getString("major")); data.put("status", doc.getString("status")); data.put("studentNumber", doc.getString("studentNumber")); } catch (Exception ignored) {}
                js("profileData", data);
            }).addOnFailureListener(e -> js("profileData", result(false, friendly(e))));
        }

        @JavascriptInterface public void updateProfile(String firstName, String lastName, String major) {
            FirebaseUser user = auth.getCurrentUser();
            if (user == null) { js("profile", result(false, "سجّل الدخول أولاً.")); return; }
            if (firstName == null || firstName.trim().isEmpty() || lastName == null || lastName.trim().isEmpty() || major == null || major.trim().isEmpty()) { js("profile", result(false, "الاسم واللقب والتخصص مطلوبة.")); return; }
            db.collection("students").whereEqualTo("uid", user.getUid()).limit(1).get().addOnSuccessListener(snap -> {
                if (snap.isEmpty()) { js("profile", result(false, "لم يتم العثور على ملف الطالب.")); return; }
                DocumentSnapshot doc = snap.getDocuments().get(0);
                if ("approved".equals(doc.getString("status"))) { js("profile", result(false, "تم اعتماد بياناتك ولا يمكن تعديلها إلا من طرف الإدارة.")); return; }
                Map<String,Object> update = new HashMap<>();
                update.put("firstName", firstName.trim()); update.put("lastName", lastName.trim()); update.put("major", major.trim());
                doc.getReference().update(update).addOnSuccessListener(v -> js("profile", result(true, "تم حفظ معلومات الملف الشخصي."))).addOnFailureListener(e -> js("profile", result(false, friendly(e))));
            }).addOnFailureListener(e -> js("profile", result(false, friendly(e))));
        }

        @JavascriptInterface public void adminUpdateStudentIdentity(String studentNumber, String firstName, String lastName, String major) {
            FirebaseUser admin = auth.getCurrentUser();
            if (admin == null) { js("adminIdentity", result(false, "سجّل الدخول أولًا.")); return; }
            if (studentNumber == null || !validSid(studentNumber) || firstName == null || firstName.trim().isEmpty() || lastName == null || lastName.trim().isEmpty() || major == null || major.trim().isEmpty()) { js("adminIdentity", result(false, "يرجى إدخال رقم جامعي واسم ولقب وتخصص صحيح.")); return; }
            admin.getIdToken(true).addOnSuccessListener(token -> {
                if (!Boolean.TRUE.equals(token.getClaims().get("admin"))) { js("adminIdentity", result(false, "ليست لديك صلاحية المدير.")); return; }
                db.collection("students").document(studentNumber).get().addOnSuccessListener(doc -> {
                    if (!doc.exists()) { js("adminIdentity", result(false, "لم يتم العثور على ملف الطالب.")); return; }
                    Map<String,Object> update = new HashMap<>(); update.put("firstName", firstName.trim()); update.put("lastName", lastName.trim()); update.put("major", major.trim()); update.put("identityUpdatedAt", com.google.firebase.firestore.FieldValue.serverTimestamp()); update.put("identityUpdatedBy", admin.getUid());
                    doc.getReference().update(update).addOnSuccessListener(v -> js("adminIdentity", result(true, "تم تصحيح بيانات الطالب بنجاح."))).addOnFailureListener(e -> js("adminIdentity", result(false, friendly(e))));
                }).addOnFailureListener(e -> js("adminIdentity", result(false, friendly(e))));
            }).addOnFailureListener(e -> js("adminIdentity", result(false, friendly(e))));
        }

        @JavascriptInterface public void createLostFound(String type, String itemName, String description, String location, String eventDate, String imageData) {
            FirebaseUser u=auth.getCurrentUser(); if(u==null){js("lostSubmit",result(false,"سجّل الدخول أولاً."));return;}
            if(!"lost".equals(type)&&!"found".equals(type)){js("lostSubmit",result(false,"نوع البلاغ غير صحيح."));return;}
            if(itemName==null||itemName.trim().isEmpty()||itemName.length()>70||description==null||description.length()>300||location==null||location.length()>100||(imageData!=null&&imageData.length()>650000)){js("lostSubmit",result(false,"تحقق من الحقول وحجم الصورة."));return;}
            db.collection("studentApplications").document(u.getUid()).get().addOnSuccessListener(app->{
                if(!app.exists()||!"approved".equals(app.getString("status"))){js("lostSubmit",result(false,"هذه الخدمة متاحة للطلبة الذين تم اعتماد حساباتهم فقط."));return;}
                Map<String,Object> doc=new HashMap<>();doc.put("ownerUid",u.getUid());doc.put("type",type);doc.put("itemName",itemName.trim());doc.put("description",description.trim());doc.put("location",location.trim());doc.put("eventDate",eventDate==null?"":eventDate);doc.put("status","pending");doc.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());if(imageData!=null&&!imageData.isEmpty())doc.put("imageData",imageData);
                db.collection("lostFoundReports").add(doc).addOnSuccessListener(ref->js("lostSubmit",result(true,"تم إرسال البلاغ. سيظهر بعد موافقة الإدارة."))).addOnFailureListener(e->js("lostSubmit",result(false,friendly(e))));
            }).addOnFailureListener(e->js("lostSubmit",result(false,friendly(e))));
        }
        @JavascriptInterface public void loadLostFound() {
            FirebaseUser u=auth.getCurrentUser();if(u==null){js("lostPublic",result(false,"سجّل الدخول أولاً."));return;}
            db.collection("lostFoundReports").whereEqualTo("status","approved").get().addOnSuccessListener(snap->{JSONArray arr=new JSONArray();for(DocumentSnapshot d:snap.getDocuments()){JSONObject x=new JSONObject();try{x.put("id",d.getId());x.put("ownerUid",d.getString("ownerUid"));x.put("type",d.getString("type"));x.put("itemName",d.getString("itemName"));x.put("description",d.getString("description"));x.put("location",d.getString("location"));x.put("eventDate",d.getString("eventDate"));x.put("imageData",d.getString("imageData"));arr.put(x);}catch(Exception ignored){}}JSONObject o=result(true,"الإعلانات المقبولة");try{o.put("items",arr);o.put("currentUid",u.getUid());}catch(Exception ignored){}js("lostPublic",o);}).addOnFailureListener(e->js("lostPublic",result(false,friendly(e))));
        }
        @JavascriptInterface public void adminLostFoundList() {
            FirebaseUser u=auth.getCurrentUser();if(u==null){js("lostAdminList",result(false,"سجّل الدخول أولاً."));return;}
            u.getIdToken(true).addOnSuccessListener(token->{if(!Boolean.TRUE.equals(token.getClaims().get("admin"))){js("lostAdminList",result(false,"ليست لديك صلاحية المدير."));return;}
                db.collection("lostFoundReports").whereEqualTo("status","pending").get().addOnSuccessListener(pending->{
                    db.collection("lostFoundReports").whereEqualTo("status","return_requested").get().addOnSuccessListener(returnRequests->{
                        List<DocumentSnapshot> reports=new ArrayList<>();reports.addAll(pending.getDocuments());reports.addAll(returnRequests.getDocuments());
                        JSONArray arr=new JSONArray();
                        if(reports.isEmpty()){JSONObject o=result(true,"لا توجد طلبات إعلانات أو تسليم قيد المراجعة.");try{o.put("items",arr);}catch(Exception ignored){}js("lostAdminList",o);return;}
                        AtomicInteger remaining=new AtomicInteger(reports.size());
                        for(DocumentSnapshot d:reports){
                            db.collection("students").whereEqualTo("uid",d.getString("ownerUid")).limit(1).get().addOnSuccessListener(studentSnap->{
                                JSONObject x=new JSONObject();try{
                                    x.put("id",d.getId());x.put("ownerUid",d.getString("ownerUid"));x.put("type",d.getString("type"));x.put("itemName",d.getString("itemName"));x.put("description",d.getString("description"));x.put("location",d.getString("location"));x.put("eventDate",d.getString("eventDate"));x.put("imageData",d.getString("imageData"));x.put("status",d.getString("status"));x.put("ownerStudentNumber",d.getString("ownerStudentNumber"));x.put("ownerFirstName",d.getString("ownerFirstName"));x.put("ownerLastName",d.getString("ownerLastName"));x.put("ownerEmail",d.getString("ownerEmail"));x.put("ownerMajor",d.getString("ownerMajor"));
                                    if(!studentSnap.isEmpty()){DocumentSnapshot st=studentSnap.getDocuments().get(0);x.put("ownerStudentNumber",st.getString("studentNumber"));x.put("ownerFirstName",st.getString("firstName"));x.put("ownerLastName",st.getString("lastName"));x.put("ownerEmail",st.getString("email"));x.put("ownerMajor",st.getString("major"));}
                                }catch(Exception ignored){}
                                synchronized(arr){arr.put(x);}
                                if(remaining.decrementAndGet()==0){JSONObject o=result(true,"بلاغات المفقودات وطلبات التسليم قيد المراجعة.");try{o.put("items",arr);}catch(Exception ignored){}js("lostAdminList",o);}
                            }).addOnFailureListener(e->{if(remaining.decrementAndGet()==0){JSONObject o=result(true,"تم تحميل بعض البلاغات، تعذر تحميل بعض بيانات المعلنين.");try{o.put("items",arr);}catch(Exception ignored){}js("lostAdminList",o);}});
                        }
                    }).addOnFailureListener(e->js("lostAdminList",result(false,friendly(e))));
                }).addOnFailureListener(e->js("lostAdminList",result(false,friendly(e))));
            }).addOnFailureListener(e->js("lostAdminList",result(false,friendly(e))));
        }

        @JavascriptInterface public void requestLostFoundReturn(String reportId) {
            FirebaseUser u=auth.getCurrentUser();if(u==null||reportId==null||reportId.trim().isEmpty()){js("lostReturn",result(false,"تعذر إرسال الطلب."));return;}
            db.collection("lostFoundReports").document(reportId).get().addOnSuccessListener(report->{
                if(!report.exists()||!u.getUid().equals(report.getString("ownerUid"))||!"approved".equals(report.getString("status"))){js("lostReturn",result(false,"لا يمكنك إرسال طلب التسليم لهذا الإعلان."));return;}
                Map<String,Object> update=new HashMap<>();update.put("status","return_requested");update.put("returnRequestedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());update.put("returnRequestedBy",u.getUid());
                report.getReference().update(update).addOnSuccessListener(v->{notifyLostReturnRequest(u,reportId);js("lostReturn",result(true,"تم إرسال طلب إغلاق الإعلان إلى الإدارة."));}).addOnFailureListener(e->js("lostReturn",result(false,friendly(e))));
            }).addOnFailureListener(e->js("lostReturn",result(false,friendly(e))));
        }
        @JavascriptInterface public void startLostFoundChat(String reportId, String ownerUid) {
            FirebaseUser u=auth.getCurrentUser();if(u==null||reportId==null||ownerUid==null||ownerUid.equals(u.getUid())){js("chatStart",result(false,"لا يمكن بدء هذه المحادثة."));return;}
            db.collection("studentApplications").document(u.getUid()).get().addOnSuccessListener(app->{if(!app.exists()||!"approved".equals(app.getString("status"))){js("chatStart",result(false,"المحادثات متاحة للطلبة المعتمدين فقط."));return;}
                db.collection("lostFoundReports").document(reportId).get().addOnSuccessListener(report->{if(!report.exists()||!"approved".equals(report.getString("status"))||!ownerUid.equals(report.getString("ownerUid"))){js("chatStart",result(false,"هذا الإعلان غير متاح للمراسلة."));return;}
                    String chatId=reportId+"_"+u.getUid();db.collection("lostFoundChats").document(chatId).get().addOnSuccessListener(existing->{if(existing.exists()){JSONObject o=result(true,"تم فتح المحادثة.");try{o.put("chatId",chatId);o.put("itemName",report.getString("itemName"));}catch(Exception ignored){}js("chatStart",o);return;}
                        Map<String,Object> chat=new HashMap<>();chat.put("reportId",reportId);chat.put("itemName",report.getString("itemName"));chat.put("participants",Arrays.asList(u.getUid(),ownerUid));chat.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());chat.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());chat.put("lastMessage","");
                        db.collection("lostFoundChats").document(chatId).set(chat).addOnSuccessListener(v->{JSONObject o=result(true,"تم إنشاء المحادثة.");try{o.put("chatId",chatId);o.put("itemName",report.getString("itemName"));}catch(Exception ignored){}js("chatStart",o);}).addOnFailureListener(e->js("chatStart",result(false,friendly(e))));
                    }).addOnFailureListener(e->js("chatStart",result(false,friendly(e))));
                }).addOnFailureListener(e->js("chatStart",result(false,friendly(e))));
            }).addOnFailureListener(e->js("chatStart",result(false,friendly(e))));
        }
        @JavascriptInterface public void loadMyChats() {
            FirebaseUser u=auth.getCurrentUser();if(u==null){js("myChats",result(false,"سجّل الدخول أولاً."));return;}
            db.collection("lostFoundChats").whereArrayContains("participants",u.getUid()).get().addOnSuccessListener(snap->{JSONArray arr=new JSONArray();for(DocumentSnapshot d:snap.getDocuments()){JSONObject x=new JSONObject();try{x.put("id",d.getId());x.put("itemName",d.getString("itemName"));x.put("lastMessage",d.getString("lastMessage"));arr.put(x);}catch(Exception ignored){}}JSONObject o=result(true,"محادثاتك");try{o.put("items",arr);}catch(Exception ignored){}js("myChats",o);}).addOnFailureListener(e->js("myChats",result(false,friendly(e))));
        }
        @JavascriptInterface public void loadChatMessages(String chatId) {
            FirebaseUser u=auth.getCurrentUser();if(u==null||chatId==null||chatId.trim().isEmpty()){js("chatMessages",result(false,"محادثة غير صالحة."));return;}
            db.collection("lostFoundChats").document(chatId).get().addOnSuccessListener(chat->{if(!chat.exists()||!((List<?>)chat.get("participants")).contains(u.getUid())){js("chatMessages",result(false,"ليس لديك إذن لقراءة هذه المحادثة."));return;}
                chat.getReference().collection("messages").orderBy("createdAt").get().addOnSuccessListener(snap->{JSONArray arr=new JSONArray();for(DocumentSnapshot d:snap.getDocuments()){JSONObject x=new JSONObject();try{x.put("senderUid",d.getString("senderUid"));x.put("text",d.getString("text"));arr.put(x);}catch(Exception ignored){}}JSONObject o=result(true,"الرسائل");try{o.put("items",arr);o.put("currentUid",u.getUid());}catch(Exception ignored){}js("chatMessages",o);}).addOnFailureListener(e->js("chatMessages",result(false,friendly(e))));
            }).addOnFailureListener(e->js("chatMessages",result(false,friendly(e))));
        }
        @JavascriptInterface public void sendChatMessage(String chatId, String message) {
            FirebaseUser u=auth.getCurrentUser();if(u==null||chatId==null||message==null||message.trim().isEmpty()||message.length()>1000){js("chatSent",result(false,"اكتب رسالة صحيحة."));return;}
            db.collection("lostFoundChats").document(chatId).get().addOnSuccessListener(chat->{if(!chat.exists()||!((List<?>)chat.get("participants")).contains(u.getUid())){js("chatSent",result(false,"ليس لديك إذن لإرسال الرسائل."));return;}
                Map<String,Object> msg=new HashMap<>();msg.put("senderUid",u.getUid());msg.put("text",message.trim());msg.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                chat.getReference().collection("messages").add(msg).addOnSuccessListener(ref->{Map<String,Object> upd=new HashMap<>();upd.put("lastMessage",message.trim());upd.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());chat.getReference().update(upd).addOnSuccessListener(v->js("chatSent",result(true,"تم إرسال الرسالة."))).addOnFailureListener(e->js("chatSent",result(false,friendly(e))));}).addOnFailureListener(e->js("chatSent",result(false,friendly(e))));
            }).addOnFailureListener(e->js("chatSent",result(false,friendly(e))));
        }
        @JavascriptInterface public void adminReviewLostFound(String reportId, String decision) {
            FirebaseUser u=auth.getCurrentUser();if(u==null||reportId==null||reportId.trim().isEmpty()||(!"approved".equals(decision)&&!"rejected".equals(decision)&&!"returned".equals(decision)&&!"return_denied".equals(decision))){js("lostReview",result(false,"بيانات المراجعة غير صحيحة."));return;}
            u.getIdToken(true).addOnSuccessListener(token->{if(!Boolean.TRUE.equals(token.getClaims().get("admin"))){js("lostReview",result(false,"ليست لديك صلاحية المدير."));return;}
                db.collection("lostFoundReports").document(reportId).get().addOnSuccessListener(report->{
                    if(!report.exists()){js("lostReview",result(false,"الإعلان غير موجود."));return;}
                    String current=report.getString("status");String status=decision.equals("return_denied")?"approved":decision;
                    if(("returned".equals(decision)||"return_denied".equals(decision))&& !"return_requested".equals(current)){js("lostReview",result(false,"لا يوجد طلب تسليم لهذا الإعلان."));return;}
                    if(("approved".equals(decision)||"rejected".equals(decision))&& !"pending".equals(current)){js("lostReview",result(false,"هذا الإعلان لم يعد قيد المراجعة."));return;}
                    Map<String,Object> update=new HashMap<>();update.put("status",status);update.put("reviewedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());update.put("reviewedBy",u.getUid());if("returned".equals(status))update.put("returnedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                    report.getReference().update(update).addOnSuccessListener(v->js("lostReview",result(true,"returned".equals(status)?"تم إغلاق الإعلان بعد تأكيد التسليم.":("return_denied".equals(decision)?"تم رفض طلب الإغلاق، وبقي الإعلان منشوراً.":("approved".equals(status)?"تم قبول البلاغ ونشره.":"تم رفض البلاغ."))))).addOnFailureListener(e->js("lostReview",result(false,friendly(e))));
                }).addOnFailureListener(e->js("lostReview",result(false,friendly(e))));
            }).addOnFailureListener(e->js("lostReview",result(false,friendly(e))));
        }

        @JavascriptInterface public void logout() { auth.signOut(); }

        @JavascriptInterface public void adminList() {
            FirebaseUser u=auth.getCurrentUser(); if(u==null){js("adminList",result(false,"سجّل الدخول أولًا."));return;}
            u.getIdToken(true).addOnSuccessListener(token->{ if(!Boolean.TRUE.equals(token.getClaims().get("admin"))){js("adminList",result(false,"ليست لديك صلاحية المدير."));return;}
                db.collection("studentApplications").get().addOnSuccessListener(snap -> db.collection("students").get().addOnSuccessListener(studentSnap -> {
                    Map<String,DocumentSnapshot> studentsByUid = new HashMap<>();
                    for (DocumentSnapshot studentDoc : studentSnap.getDocuments()) studentsByUid.put(studentDoc.getString("uid"), studentDoc);
                    JSONArray arr = new JSONArray();
                    JSONArray history = new JSONArray();
                    int pendingCount=0, approvedCount=0, rejectedCount=0, suspendedCount=0;
                    for (DocumentSnapshot d : snap.getDocuments()) { JSONObject x = new JSONObject(); try {
                        String status = d.getString("status");
                        if ("pending".equals(status)) pendingCount++;
                        else if ("approved".equals(status)) approvedCount++;
                        else if ("rejected".equals(status)) rejectedCount++;
                        else if ("suspended".equals(status)) suspendedCount++;
                        x.put("uid", d.getId()); x.put("studentNumber", d.getString("studentNumber")); x.put("status", status); x.put("frontPath", d.getString("frontPath")); x.put("backPath", d.getString("backPath"));
                        DocumentSnapshot student = studentsByUid.get(d.getId());
                        if (student != null) { x.put("firstName", student.getString("firstName")); x.put("lastName", student.getString("lastName")); x.put("major", student.getString("major")); }
                        if ("pending".equals(status)) arr.put(x); else history.put(x);
                    } catch (Exception ignored) {} }
                    JSONObject stats = new JSONObject();
                    try { stats.put("pending",pendingCount); stats.put("approved",approvedCount); stats.put("rejected",rejectedCount); stats.put("suspended",suspendedCount); stats.put("total",studentSnap.size()); } catch (Exception ignored) {}
                    JSONObject o = result(true, "تم تحميل طلبات المراجعة والإحصائيات."); try { o.put("items", arr); o.put("history", history); o.put("stats", stats); } catch (Exception ignored) {} js("adminList", o);
                }).addOnFailureListener(e -> js("adminList", result(false, friendly(e))))).addOnFailureListener(e -> js("adminList", result(false, friendly(e))));
            }).addOnFailureListener(e->js("adminList",result(false,friendly(e))));
        }
        @JavascriptInterface public void adminSetStatus(String uid, String status, String rejectionReason) {
            if (uid == null || uid.trim().isEmpty() ||
                (!"approved".equals(status) && !"rejected".equals(status) && !"suspended".equals(status))) {
                js("adminAction",result(false,"بيانات تغيير الحالة غير صالحة.")); return;
            }
            FirebaseUser u=auth.getCurrentUser();
            if(u==null){js("adminAction",result(false,"سجّل الدخول أولًا."));return;}
            u.getIdToken(true).addOnSuccessListener(token->{
                if(!Boolean.TRUE.equals(token.getClaims().get("admin"))){js("adminAction",result(false,"ليست لديك صلاحية المدير."));return;}
                db.collection("students").whereEqualTo("uid", uid).get().addOnSuccessListener(snap -> {
                    Map<String,Object> update=new HashMap<>();
                    update.put("status",status);
                    if ("rejected".equals(status)) update.put("rejectionReason", rejectionReason == null ? "" : rejectionReason.trim());
                    update.put("reviewedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                    update.put("reviewedBy",u.getUid());
                    com.google.firebase.firestore.WriteBatch batch=db.batch();
                    batch.update(db.collection("studentApplications").document(uid), update);
                    for (DocumentSnapshot studentDoc : snap.getDocuments()) {
                        batch.update(studentDoc.getReference(), update);
                    }
                    batch.commit().addOnSuccessListener(v -> {
                        notifyStatusChange(u, uid, status);
                        String message="approved".equals(status)?"تم قبول حساب الطالب بنجاح.":("rejected".equals(status)?"تم رفض طلب الطالب.":"تم إيقاف حساب الطالب.");
                        js("adminAction",result(true,message));
                    }).addOnFailureListener(e -> js("adminAction",result(false,friendly(e))));
                }).addOnFailureListener(e -> js("adminAction",result(false,friendly(e))));
            }).addOnFailureListener(e -> js("adminAction",result(false,friendly(e))));
        }
        @JavascriptInterface public void adminDeleteCard(String uid) {
            FirebaseUser u=auth.getCurrentUser(); if(u==null){js("adminDelete",result(false,"سجّل الدخول أولًا."));return;}
            u.getIdToken(true).addOnSuccessListener(token -> networkExecutor.execute(() -> {
                try {
                    storageRequest(token.getToken(), "delete", "uid", uid);
                    Map<String,Object> update=new HashMap<>(); update.put("frontPath",""); update.put("backPath",""); update.put("cardDeletedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                    db.collection("studentApplications").document(uid).update(update).addOnSuccessListener(v->js("adminDelete",result(true,"تم حذف صور البطاقة."))).addOnFailureListener(e->js("adminDelete",result(false,friendly(e))));
                } catch(Exception e) { js("adminDelete",result(false,e.getMessage()==null?"تعذر حذف الصور.":e.getMessage())); }
            })).addOnFailureListener(e->js("adminDelete",result(false,friendly(e))));
        }
        @JavascriptInterface public void adminImageUrl(String path, String callbackKey) {
            FirebaseUser u=auth.getCurrentUser(); if(u==null)return;
            u.getIdToken(true).addOnSuccessListener(token -> networkExecutor.execute(() -> {
                try { JSONObject body=new JSONObject(); body.put("action","download"); body.put("path",path); body.put("key",callbackKey);
                    JSONObject response=callCardStorage(token.getToken(),body); JSONObject o=result(true,"ok"); o.put("image",response.getString("image")); o.put("contentType",response.optString("contentType", "image/jpeg")); o.put("key",callbackKey); js("adminImage",o);
                } catch(Exception e) { js("adminImage",result(false,e.getMessage()==null?"تعذر تحميل صورة البطاقة.":e.getMessage())); }
            }));
        }
    }
    private String friendly(Exception e) { String m=e==null?"حدث خطأ غير متوقع.":e.getMessage(); return m==null?"حدث خطأ غير متوقع.":m; }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==FILE_CHOOSER_REQUEST&&filePathCallback!=null){Uri[] results=null;if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)results=new Uri[]{data.getData()};filePathCallback.onReceiveValue(results);filePathCallback=null;}}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
