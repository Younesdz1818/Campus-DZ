package dz.campus.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.util.Base64;
import android.graphics.Color;
import android.view.Window;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 4102;
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private static final String SUPABASE_FUNCTION_URL = "https://fucfpxtwlptoxnfxhavm.supabase.co/functions/v1/card-storage";
    private static final String SUPABASE_PUBLISHABLE_KEY = "sb_publishable_ICVgVaO2-vO7_SV9kldm1g_BVSLPQDT";
    private final Executor networkExecutor = java.util.concurrent.Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(16,43,70));
        getWindow().setNavigationBarColor(Color.BLACK);
        FirebaseApp.initializeApp(this);
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(243,246,250));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadsImagesAutomatically(true);
        webView.addJavascriptInterface(new CampusBridge(), "CampusBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                try { startActivityForResult(Intent.createChooser(intent, "اختر صورة البطاقة"), FILE_CHOOSER_REQUEST); }
                catch (Exception e) { filePathCallback = null; return false; }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void js(String method, JSONObject data) {
        runOnUiThread(() -> webView.evaluateJavascript("window.onCampusResult && window.onCampusResult(" + JSONObject.quote(method) + "," + data.toString() + ")", null));
    }
    private JSONObject result(boolean ok, String message) {
        JSONObject o = new JSONObject(); try { o.put("ok", ok); o.put("message", message); } catch(Exception ignored){} return o;
    }
    private String emailFor(String sid) { return sid + "@campusdz.app"; }
    private boolean validSid(String sid) { return sid != null && sid.matches("[0-9]{8}"); }
    private byte[] decodeImage(String data) {
        if (data == null || data.length() < 20) return null;
        int comma = data.indexOf(',');
        String raw = comma >= 0 ? data.substring(comma + 1) : data;
        try { return Base64.decode(raw, Base64.DEFAULT); } catch(Exception e) { return null; }
    }

    private String extensionFor(String data) { return data != null && data.startsWith("data:image/png") ? "png" : "jpg"; }
    private String contentTypeFor(String data) { return "png".equals(extensionFor(data)) ? "image/png" : "image/jpeg"; }
    private JSONObject callCardStorage(String idToken, JSONObject payload) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(SUPABASE_FUNCTION_URL).openConnection();
        conn.setRequestMethod("POST"); conn.setConnectTimeout(20000); conn.setReadTimeout(30000);
        conn.setDoOutput(true); conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("apikey", SUPABASE_PUBLISHABLE_KEY);
        conn.setRequestProperty("Authorization", "Bearer " + idToken);
        byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream out = conn.getOutputStream()) { out.write(body); }
        int code = conn.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        if (in != null) { byte[] chunk = new byte[8192]; int n; while ((n = in.read(chunk)) != -1) buffer.write(chunk, 0, n); in.close(); }
        conn.disconnect();
        JSONObject response = new JSONObject(buffer.toString("UTF-8"));
        if (code < 200 || code >= 300 || !response.optBoolean("ok", false))
            throw new Exception(response.optString("error", "Supabase request failed (" + code + ")"));
        return response;
    }
    private JSONObject storageRequest(String token, String action, String key, String value) throws Exception {
        JSONObject body = new JSONObject(); body.put("action", action); body.put(key, value);
        return callCardStorage(token, body);
    }
    private String uploadCard(String token, String side, String data) throws Exception {
        if (data == null || data.isEmpty()) return "";
        String raw = data.substring(data.indexOf(',') >= 0 ? data.indexOf(',') + 1 : 0);
        JSONObject body = new JSONObject(); body.put("action", "upload"); body.put("side", side);
        body.put("contentType", contentTypeFor(data)); body.put("imageBase64", raw);
        return callCardStorage(token, body).getString("path");
    }

    private class CampusBridge {
        @JavascriptInterface public void register(String sid, String password, String firstName, String lastName, String contactEmail, String major, String front, String back) {
            if (!validSid(sid)) { js("register", result(false, "يجب أن يتكون الرقم الجامعي من 8 أرقام.")); return; }
            if (password == null || password.length() < 6) { js("register", result(false, "كلمة المرور يجب أن تكون 6 أحرف على الأقل.")); return; }
            if (firstName == null || firstName.trim().isEmpty() || lastName == null || lastName.trim().isEmpty()
                || major == null || major.trim().isEmpty() || contactEmail == null || !android.util.Patterns.EMAIL_ADDRESS.matcher(contactEmail).matches()) {
                js("register", result(false, "يرجى إدخال الاسم واللقب والتخصص وبريد إلكتروني صحيح.")); return;
            }
            byte[] frontBytes = decodeImage(front), backBytes = decodeImage(back);
            if (frontBytes == null) { js("register", result(false, "صورة الوجه الأمامي مطلوبة.")); return; }
            if (frontBytes.length > 3*1024*1024 || (backBytes != null && backBytes.length > 3*1024*1024)) { js("register", result(false, "حجم كل صورة يجب ألا يتجاوز 3 ميغابايت.")); return; }
            auth.createUserWithEmailAndPassword(emailFor(sid), password).addOnSuccessListener(authResult -> {
                FirebaseUser user = authResult.getUser(); if (user == null) { js("register", result(false, "تعذر إنشاء الحساب.")); return; }
                String uid = user.getUid();
                user.getIdToken(true).addOnSuccessListener(token -> networkExecutor.execute(() -> {
                    try {
                        String frontPath = uploadCard(token.getToken(), "front", front);
                        String backPath = back == null || back.isEmpty() ? "" : uploadCard(token.getToken(), "back", back);
                        Map<String,Object> app = new HashMap<>(); app.put("uid",uid); app.put("studentNumber",sid); app.put("status","pending"); app.put("frontPath",frontPath); app.put("backPath",backPath); app.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                        Map<String,Object> number = new HashMap<>(); number.put("uid",uid); number.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                        Map<String,Object> student = new HashMap<>(); student.put("uid",uid); student.put("studentNumber",sid);
                        student.put("firstName",firstName.trim()); student.put("lastName",lastName.trim());
                        student.put("email",contactEmail.trim()); student.put("major",major.trim()); student.put("status","pending");
                        student.put("frontCardImage",frontPath); student.put("backCardImage",backPath);
                        student.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                        db.runTransaction(transaction -> { transaction.set(db.collection("studentNumbers").document(sid), number); transaction.set(db.collection("studentApplications").document(uid), app); transaction.set(db.collection("students").document(sid), student); return null; })
                            .addOnSuccessListener(x -> js("register", result(true,"تم إرسال طلبك بنجاح. حسابك الآن قيد المراجعة.")))
                            .addOnFailureListener(e -> { user.delete(); js("register", result(false, (e.getMessage()!=null && e.getMessage().contains("PERMISSION_DENIED")) ? "هذا الرقم الجامعي مسجل مسبقًا أو تعذر إتمام الطلب." : friendly(e))); });
                    } catch (Exception e) { user.delete(); js("register", result(false,"تعذر رفع صور البطاقة: "+(e.getMessage()==null?"تحقق من الاتصال وإعدادات Supabase.":e.getMessage()))); }
                })).addOnFailureListener(e -> { user.delete(); js("register", result(false,"تعذر التحقق من الحساب: "+friendly(e))); });
            }).addOnFailureListener(e -> js("register", result(false, friendly(e))));
        }

        @JavascriptInterface public void login(String sid, String password) {
            if (!validSid(sid) || password == null || password.isEmpty()) { js("login", result(false,"أدخل رقمًا جامعيًا صحيحًا وكلمة المرور.")); return; }
            auth.signInWithEmailAndPassword(emailFor(sid), password).addOnSuccessListener(a -> {
                FirebaseUser user = auth.getCurrentUser();
                if (user == null) { js("login", result(false,"تعذر التحقق من الحساب.")); return; }
                user.getIdToken(true).addOnSuccessListener(token -> {
                    Object admin = token.getClaims().get("admin");
                    if (Boolean.TRUE.equals(admin)) { JSONObject o=result(true,"تم الدخول بصلاحية المدير."); try{o.put("role","admin");o.put("uid",user.getUid());}catch(Exception ignored){} js("login",o); return; }
                    db.collection("studentApplications").document(user.getUid()).get().addOnSuccessListener(doc -> {
                        String status = doc.getString("status");
                        if ("approved".equals(status)) { JSONObject o=result(true,"مرحبًا بك في Campus DZ."); try{o.put("role","student");o.put("uid",user.getUid());o.put("studentNumber",sid);}catch(Exception ignored){} js("login",o); }
                        else { auth.signOut(); String msg="pending".equals(status)?"حسابك قيد المراجعة. ستتمكن من الدخول بعد موافقة المدير.":"rejected".equals(status)?"تم رفض طلب التسجيل. يرجى التواصل مع الإدارة.":"suspended".equals(status)?"تم إيقاف حسابك.":"لم يتم العثور على طلب تحقق لهذا الحساب."; js("login",result(false,msg)); }
                    }).addOnFailureListener(e -> { auth.signOut(); js("login",result(false,"تعذر التحقق من حالة الحساب.")); });
                }).addOnFailureListener(e -> js("login",result(false,friendly(e))));
            }).addOnFailureListener(e -> js("login",result(false,"رقم التسجيل أو كلمة المرور غير صحيحة.")));
        }

        @JavascriptInterface public void getStudentProfile() {
            FirebaseUser user = auth.getCurrentUser();
            if (user == null) { js("profileData", result(false, "سجّل الدخول أولاً.")); return; }
            db.collection("students").whereEqualTo("uid", user.getUid()).limit(1).get().addOnSuccessListener(snap -> {
                if (snap.isEmpty()) { js("profileData", result(false, "لم يتم العثور على ملف الطالب.")); return; }
                DocumentSnapshot doc = snap.getDocuments().get(0);
                JSONObject data = result(true, "تم تحميل بيانات الطالب.");
                try { data.put("firstName", doc.getString("firstName")); data.put("lastName", doc.getString("lastName")); data.put("major", doc.getString("major")); data.put("status", doc.getString("status")); data.put("studentNumber", doc.getString("studentNumber")); } catch (Exception ignored) {}
                js("profileData", data);
            }).addOnFailureListener(e -> js("profileData", result(false, friendly(e))));
        }

        @JavascriptInterface public void updateProfile(String firstName, String lastName, String major) {
            FirebaseUser user = auth.getCurrentUser();
            if (user == null) { js("profile", result(false, "سجّل الدخول أولاً.")); return; }
            if (firstName == null || firstName.trim().isEmpty() || lastName == null || lastName.trim().isEmpty() || major == null || major.trim().isEmpty()) { js("profile", result(false, "الاسم واللقب والتخصص مطلوبة.")); return; }
            db.collection("students").whereEqualTo("uid", user.getUid()).limit(1).get().addOnSuccessListener(snap -> {
                if (snap.isEmpty()) { js("profile", result(false, "لم يتم العثور على ملف الطالب.")); return; }
                DocumentSnapshot doc = snap.getDocuments().get(0);
                if ("approved".equals(doc.getString("status"))) { js("profile", result(false, "تم اعتماد بياناتك ولا يمكن تعديلها إلا من طرف الإدارة.")); return; }
                Map<String,Object> update = new HashMap<>();
                update.put("firstName", firstName.trim()); update.put("lastName", lastName.trim()); update.put("major", major.trim());
                doc.getReference().update(update).addOnSuccessListener(v -> js("profile", result(true, "تم حفظ معلومات الملف الشخصي."))).addOnFailureListener(e -> js("profile", result(false, friendly(e))));
            }).addOnFailureListener(e -> js("profile", result(false, friendly(e))));
        }

        @JavascriptInterface public void adminUpdateStudentIdentity(String studentNumber, String firstName, String lastName, String major) {
            FirebaseUser admin = auth.getCurrentUser();
            if (admin == null) { js("adminIdentity", result(false, "سجّل الدخول أولًا.")); return; }
            if (studentNumber == null || !validSid(studentNumber) || firstName == null || firstName.trim().isEmpty() || lastName == null || lastName.trim().isEmpty() || major == null || major.trim().isEmpty()) { js("adminIdentity", result(false, "يرجى إدخال رقم جامعي واسم ولقب وتخصص صحيح.")); return; }
            admin.getIdToken(true).addOnSuccessListener(token -> {
                if (!Boolean.TRUE.equals(token.getClaims().get("admin"))) { js("adminIdentity", result(false, "ليست لديك صلاحية المدير.")); return; }
                db.collection("students").document(studentNumber).get().addOnSuccessListener(doc -> {
                    if (!doc.exists()) { js("adminIdentity", result(false, "لم يتم العثور على ملف الطالب.")); return; }
                    Map<String,Object> update = new HashMap<>(); update.put("firstName", firstName.trim()); update.put("lastName", lastName.trim()); update.put("major", major.trim()); update.put("identityUpdatedAt", com.google.firebase.firestore.FieldValue.serverTimestamp()); update.put("identityUpdatedBy", admin.getUid());
                    doc.getReference().update(update).addOnSuccessListener(v -> js("adminIdentity", result(true, "تم تصحيح بيانات الطالب بنجاح."))).addOnFailureListener(e -> js("adminIdentity", result(false, friendly(e))));
                }).addOnFailureListener(e -> js("adminIdentity", result(false, friendly(e))));
            }).addOnFailureListener(e -> js("adminIdentity", result(false, friendly(e))));
        }

        @JavascriptInterface public void logout() { auth.signOut(); }

        @JavascriptInterface public void adminList() {
            FirebaseUser u=auth.getCurrentUser(); if(u==null){js("adminList",result(false,"سجّل الدخول أولًا."));return;}
            u.getIdToken(true).addOnSuccessListener(token->{ if(!Boolean.TRUE.equals(token.getClaims().get("admin"))){js("adminList",result(false,"ليست لديك صلاحية المدير."));return;}
                db.collection("studentApplications").get().addOnSuccessListener(snap -> db.collection("students").get().addOnSuccessListener(studentSnap -> {
                    Map<String,DocumentSnapshot> studentsByUid = new HashMap<>();
                    for (DocumentSnapshot studentDoc : studentSnap.getDocuments()) studentsByUid.put(studentDoc.getString("uid"), studentDoc);
                    JSONArray arr = new JSONArray();
                    JSONArray history = new JSONArray();
                    for (DocumentSnapshot d : snap.getDocuments()) { JSONObject x = new JSONObject(); try {
                        String status = d.getString("status");
                        x.put("uid", d.getId()); x.put("studentNumber", d.getString("studentNumber")); x.put("status", status); x.put("frontPath", d.getString("frontPath")); x.put("backPath", d.getString("backPath"));
                        DocumentSnapshot student = studentsByUid.get(d.getId());
                        if (student != null) { x.put("firstName", student.getString("firstName")); x.put("lastName", student.getString("lastName")); x.put("major", student.getString("major")); }
                        if ("pending".equals(status)) arr.put(x); else history.put(x);
                    } catch (Exception ignored) {} }
                    JSONObject o = result(true, "تم تحميل طلبات المراجعة."); try { o.put("items", arr); o.put("history", history); } catch (Exception ignored) {} js("adminList", o);
                }).addOnFailureListener(e -> js("adminList", result(false, friendly(e))))).addOnFailureListener(e -> js("adminList", result(false, friendly(e))));
            }).addOnFailureListener(e->js("adminList",result(false,friendly(e))));
        }
        @JavascriptInterface public void adminSetStatus(String uid, String status) {
            if (uid == null || uid.trim().isEmpty() ||
                (!"approved".equals(status) && !"rejected".equals(status) && !"suspended".equals(status))) {
                js("adminAction",result(false,"بيانات تغيير الحالة غير صالحة.")); return;
            }
            FirebaseUser u=auth.getCurrentUser();
            if(u==null){js("adminAction",result(false,"سجّل الدخول أولًا."));return;}
            u.getIdToken(true).addOnSuccessListener(token->{
                if(!Boolean.TRUE.equals(token.getClaims().get("admin"))){js("adminAction",result(false,"ليست لديك صلاحية المدير."));return;}
                db.collection("students").whereEqualTo("uid", uid).get().addOnSuccessListener(snap -> {
                    Map<String,Object> update=new HashMap<>();
                    update.put("status",status);
                    update.put("reviewedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                    update.put("reviewedBy",u.getUid());
                    com.google.firebase.firestore.WriteBatch batch=db.batch();
                    batch.update(db.collection("studentApplications").document(uid), update);
                    for (DocumentSnapshot studentDoc : snap.getDocuments()) {
                        batch.update(studentDoc.getReference(), update);
                    }
                    batch.commit().addOnSuccessListener(v -> {
                        String message="approved".equals(status)?"تم قبول حساب الطالب بنجاح.":("rejected".equals(status)?"تم رفض طلب الطالب.":"تم إيقاف حساب الطالب.");
                        js("adminAction",result(true,message));
                    }).addOnFailureListener(e -> js("adminAction",result(false,friendly(e))));
                }).addOnFailureListener(e -> js("adminAction",result(false,friendly(e))));
            }).addOnFailureListener(e -> js("adminAction",result(false,friendly(e))));
        }
        @JavascriptInterface public void adminDeleteCard(String uid) {
            FirebaseUser u=auth.getCurrentUser(); if(u==null){js("adminDelete",result(false,"سجّل الدخول أولًا."));return;}
            u.getIdToken(true).addOnSuccessListener(token -> networkExecutor.execute(() -> {
                try {
                    storageRequest(token.getToken(), "delete", "uid", uid);
                    Map<String,Object> update=new HashMap<>(); update.put("frontPath",""); update.put("backPath",""); update.put("cardDeletedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                    db.collection("studentApplications").document(uid).update(update).addOnSuccessListener(v->js("adminDelete",result(true,"تم حذف صور البطاقة."))).addOnFailureListener(e->js("adminDelete",result(false,friendly(e))));
                } catch(Exception e) { js("adminDelete",result(false,e.getMessage()==null?"تعذر حذف الصور.":e.getMessage())); }
            })).addOnFailureListener(e->js("adminDelete",result(false,friendly(e))));
        }
        @JavascriptInterface public void adminImageUrl(String path, String callbackKey) {
            FirebaseUser u=auth.getCurrentUser(); if(u==null)return;
            u.getIdToken(true).addOnSuccessListener(token -> networkExecutor.execute(() -> {
                try { JSONObject body=new JSONObject(); body.put("action","download"); body.put("path",path); body.put("key",callbackKey);
                    JSONObject response=callCardStorage(token.getToken(),body); JSONObject o=result(true,"ok"); o.put("image",response.getString("image")); o.put("contentType",response.optString("contentType", "image/jpeg")); o.put("key",callbackKey); js("adminImage",o);
                } catch(Exception e) { js("adminImage",result(false,e.getMessage()==null?"تعذر تحميل صورة البطاقة.":e.getMessage())); }
            }));
        }
    }
    private String friendly(Exception e) { String m=e==null?"حدث خطأ غير متوقع.":e.getMessage(); return m==null?"حدث خطأ غير متوقع.":m; }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==FILE_CHOOSER_REQUEST&&filePathCallback!=null){Uri[] results=null;if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)results=new Uri[]{data.getData()};filePathCallback.onReceiveValue(results);filePathCallback=null;}}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
