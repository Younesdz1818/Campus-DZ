Campus DZ — الإصدار 2.1
========================

هذا هو مجلد المشروع Android الأصلي. يحافظ على الواجهة الحالية ويضيف/يعتمد:
- رقم التسجيل الجامعي: 8 أرقام بالضبط.
- تسجيل الدخول: الرقم الجامعي وكلمة المرور فقط.
- كلمة المرور عند التسجيل: 6 أحرف على الأقل، مع تأكيد التطابق.
- صورة الوجه الأمامي للبطاقة إلزامية، والخلفي اختياري.
- رفع الصور إلى Firebase Storage، وإنشاء طلب Firestore بحالة pending.
- منع الطالب من استخدام التطبيق حتى يوافق المدير (approved).
- لوحة المدير تتطلب Firebase Custom Claim باسم admin=true.

قبل تجربة التسجيل الحقيقي:
1. تأكد من تفعيل Email/Password في Firebase Authentication.
2. أنشئ Firestore Database وFirebase Storage.
3. انشر الملفين firestore.rules وstorage.rules في خدمتيهما.
4. تأكد أن app/google-services.json يخص مشروع Firebase الصحيح وحزمة dz.campus.app.
5. امنح حساب المدير Custom Claim باسم admin=true من بيئة موثوقة باستخدام Firebase Admin SDK. لا تضع مفتاح الخدمة داخل التطبيق.
6. اختبر أولاً بحسابات وأرقام تجريبية، ولا ترفع بطاقات طلاب حقيقية قبل نشر القواعد وإبلاغ المستخدمين بسياسة الخصوصية والاحتفاظ بالصور.

بناء APK عبر GitHub Actions:
- ارفع مجلد CampusDZ_Android كاملاً إلى مستودع GitHub، أو ارفع محتوياته إلى جذر المستودع.
- افتح Actions ثم Build Campus DZ APK ثم Run workflow.
- بعد نجاح المهمة، نزّل Artifact باسم Campus-DZ-APK.

البناء المحلي:
- افتح CampusDZ_Android في Android Studio.
- نفّذ Gradle Sync ثم Build > Build APK(s).

مهم:
- ملف APK لم يُبنَ أو يُختبر على جهاز فعلي ضمن هذه المراجعة.
- التطبيق لا يتصل بقاعدة بيانات الجامعة الرسمية للتحقق من الرقم؛ المدير يراجع صورة البطاقة يدوياً.
- حساب Firebase يستخدم بريداً داخلياً اصطناعياً بالشكل {studentNumber}@campusdz.app؛ لا يوجد تحقق من بريد الطالب.
