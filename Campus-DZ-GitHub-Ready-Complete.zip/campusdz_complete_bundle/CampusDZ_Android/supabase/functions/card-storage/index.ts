import { createClient } from "npm:@supabase/supabase-js@2";
import { createRemoteJWKSet, jwtVerify } from "npm:jose@5";

const FIREBASE_PROJECT_ID = "campus-dz-d2a18";
const FIREBASE_JWKS = createRemoteJWKSet(new URL("https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com"));

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

async function verifyFirebaseToken(idToken: string) {
  const { payload } = await jwtVerify(idToken, FIREBASE_JWKS, {
    issuer: `https://securetoken.google.com/${FIREBASE_PROJECT_ID}`,
    audience: FIREBASE_PROJECT_ID,
  });
  if (typeof payload.sub !== "string" || !payload.sub) throw new Error("Invalid Firebase user");
  return payload;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const idToken = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
    if (!idToken) return json({ error: "Missing Firebase ID token" }, 401);

    const decoded = await verifyFirebaseToken(idToken);
    const isAdmin = decoded.admin === true;
    const body = await req.json();
    const action = String(body.action ?? "");
    const bucket = "student-cards";
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { persistSession: false } },
    );

    if (action === "upload") {
      if (isAdmin) return json({ error: "Admin accounts cannot upload student cards" }, 403);
      const side = body.side === "back" ? "back" : body.side === "front" ? "front" : "";
      if (!side) return json({ error: "Invalid card side" }, 400);
      const contentType = String(body.contentType ?? "");
      if (!["image/jpeg", "image/png"].includes(contentType)) return json({ error: "Only JPEG and PNG are allowed" }, 400);
      const encoded = String(body.imageBase64 ?? "");
      if (!encoded || encoded.length > 4_200_000) return json({ error: "Image exceeds the 3 MB limit" }, 413);
      const binary = Uint8Array.from(atob(encoded), (c) => c.charCodeAt(0));
      if (binary.byteLength > 3 * 1024 * 1024) return json({ error: "Image exceeds the 3 MB limit" }, 413);
      const path = `${decoded.sub}/${side}.${contentType === "image/png" ? "png" : "jpg"}`;
      const { error } = await supabase.storage.from(bucket).upload(path, binary, {
        contentType, upsert: true,
      });
      if (error) throw error;
      return json({ ok: true, path });
    }

    if (!isAdmin) return json({ error: "Admin permission required" }, 403);
    if (action === "download") {
      const path = String(body.path ?? "");
      if (!/^[A-Za-z0-9_-]+\/(front|back)\.(jpg|png)$/.test(path)) return json({ error: "Invalid path" }, 400);
      const { data, error } = await supabase.storage.from(bucket).download(path);
      if (error) throw error;
      const bytes = new Uint8Array(await data.arrayBuffer());
      let binary = "";
      for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
      return json({ ok: true, image: btoa(binary), contentType: data.type || "image/jpeg", key: String(body.key ?? "") });
    }
    if (action === "delete") {
      const uid = String(body.uid ?? "");
      if (!/^[A-Za-z0-9_-]+$/.test(uid)) return json({ error: "Invalid user id" }, 400);
      const { error } = await supabase.storage.from(bucket).remove([
        `${uid}/front.jpg`, `${uid}/front.png`, `${uid}/back.jpg`, `${uid}/back.png`,
      ]);
      if (error) throw error;
      return json({ ok: true });
    }
    return json({ error: "Unknown action" }, 400);
  } catch (error) {
    console.error("card-storage error", error);
    return json({ error: "Request could not be completed" }, 500);
  }
});
